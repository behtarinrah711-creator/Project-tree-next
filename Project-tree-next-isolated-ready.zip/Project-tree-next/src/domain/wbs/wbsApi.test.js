import test from 'node:test';
import assert from 'node:assert/strict';
import { canAcceptChild, itemKind, isStage, isWork, lineTotal, normalizeItem } from './normalize.js';
import { projectEstimateTotal, rollupEstimate } from './estimate.js';
import { stampCreate, stampUpdate } from './timestamps.js';
import { validateWbsExport, WBS_EXPORT_SCHEMA } from './exportSchema.js';

test('old tasks without kind read as work items', () => {
  assert.equal(itemKind({ id:'a', text:'بتن' }), 'work');
  assert.equal(isWork({ id:'a', text:'بتن' }), true);
  assert.equal(isStage({ id:'a', text:'بتن' }), false);
});

test('stage may hold stage or work; work may not hold stage', () => {
  assert.equal(canAcceptChild({ kind:'stage' }, 'stage'), true);
  assert.equal(canAcceptChild({ kind:'stage' }, 'work'), true);
  assert.equal(canAcceptChild({ kind:'work' }, 'work'), true);
  assert.equal(canAcceptChild({ kind:'work' }, 'stage'), false);
});

test('estimate is quantity times unit cost and rolls up', () => {
  const child = { kind:'work', quantity:2, unitCost:10, subtasks:[] };
  const nested = { kind:'work', quantity:1, unitCost:5, subtasks:[child] };
  const stage = { kind:'stage', subtasks:[nested] };
  assert.equal(lineTotal(child), 20);
  assert.equal(rollupEstimate([stage]), 25);
  assert.equal(projectEstimateTotal([stage], [{ quantity:2, unitCost:3 }]), 31);
});

test('timestamps create then update createdAt stays', () => {
  const created = stampCreate({ id:'1' }, () => new Date('2026-01-01T00:00:00.000Z'));
  const updated = stampUpdate(created, () => new Date('2026-01-02T00:00:00.000Z'));
  assert.equal(created.createdAt, '2026-01-01T00:00:00.000Z');
  assert.equal(updated.createdAt, '2026-01-01T00:00:00.000Z');
  assert.equal(updated.updatedAt, '2026-01-02T00:00:00.000Z');
});

test('export schema is versioned and old nodes normalize as work', () => {
  const payload = { schema: WBS_EXPORT_SCHEMA, items: [normalizeItem({ id:'t1', text:'old' })] };
  assert.equal(validateWbsExport(payload).ok, true);
  assert.equal(payload.items[0].kind, 'work');
  assert.equal(validateWbsExport({ schema:'other', items:[] }).ok, false);
});
